/***************************************************************
<Your Name>
Created: yyyy/mm/dd

Description:
<Decription>
**************************************************************
<Updater Name>
Updated: yyyy/mm/dd

Description:
<Decription> 
****************************************************************/
	
USE [tadpole_db]
GO

print '' print '*** creating ...'

	